package fit.se2.se02_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Se02ProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(Se02ProjectApplication.class, args);
	}

}
