package fit.se2.se02_project.dto;

public class ProductQuantityDTO {
}
