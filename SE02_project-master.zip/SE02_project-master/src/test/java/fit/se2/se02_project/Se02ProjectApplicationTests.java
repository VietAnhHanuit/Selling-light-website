package fit.se2.se02_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Se02ProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
